﻿namespace _1SistemaDeNomina.Presentacion
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnLimpiar = new System.Windows.Forms.Button();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.btnGenerarReporte = new System.Windows.Forms.Button();
            this.btnEditar = new System.Windows.Forms.Button();
            this.btnEliminar = new System.Windows.Forms.Button();
            this.btnAgregar = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.txtNombre = new System.Windows.Forms.TextBox();
            this.txtapellidoPaterno = new System.Windows.Forms.TextBox();
            this.txtnumeroSeguroSocial = new System.Windows.Forms.TextBox();
            this.txtsalarioSemanal = new System.Windows.Forms.TextBox();
            this.txtsueldoPorHora = new System.Windows.Forms.TextBox();
            this.txttarifaComision = new System.Windows.Forms.TextBox();
            this.txthorasTrabajadas = new System.Windows.Forms.TextBox();
            this.txtventasBrutas = new System.Windows.Forms.TextBox();
            this.txtsalarioBase = new System.Windows.Forms.TextBox();
            this.listView1 = new System.Windows.Forms.ListView();
            this.columnHeader0 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader4 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader5 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader6 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader7 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader8 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader9 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.SuspendLayout();
            // 
            // btnLimpiar
            // 
            this.btnLimpiar.Location = new System.Drawing.Point(830, 321);
            this.btnLimpiar.Name = "btnLimpiar";
            this.btnLimpiar.Size = new System.Drawing.Size(130, 41);
            this.btnLimpiar.TabIndex = 14;
            this.btnLimpiar.Text = "Limpiar";
            this.btnLimpiar.UseVisualStyleBackColor = true;
            this.btnLimpiar.Click += new System.EventHandler(this.btnCancelar_Click);
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(12, 25);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(316, 28);
            this.comboBox1.TabIndex = 13;
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // btnGenerarReporte
            // 
            this.btnGenerarReporte.Location = new System.Drawing.Point(622, 321);
            this.btnGenerarReporte.Name = "btnGenerarReporte";
            this.btnGenerarReporte.Size = new System.Drawing.Size(130, 41);
            this.btnGenerarReporte.TabIndex = 12;
            this.btnGenerarReporte.Text = "Reporte";
            this.btnGenerarReporte.UseVisualStyleBackColor = true;
            this.btnGenerarReporte.Click += new System.EventHandler(this.btnGenerarReporte_Click);
            // 
            // btnEditar
            // 
            this.btnEditar.Location = new System.Drawing.Point(422, 321);
            this.btnEditar.Name = "btnEditar";
            this.btnEditar.Size = new System.Drawing.Size(130, 41);
            this.btnEditar.TabIndex = 10;
            this.btnEditar.Text = "Editar";
            this.btnEditar.UseVisualStyleBackColor = true;
            this.btnEditar.Click += new System.EventHandler(this.btnEditar_Click);
            // 
            // btnEliminar
            // 
            this.btnEliminar.Location = new System.Drawing.Point(223, 321);
            this.btnEliminar.Name = "btnEliminar";
            this.btnEliminar.Size = new System.Drawing.Size(130, 41);
            this.btnEliminar.TabIndex = 9;
            this.btnEliminar.Text = "Eliminar";
            this.btnEliminar.UseVisualStyleBackColor = true;
            this.btnEliminar.Click += new System.EventHandler(this.btnEliminar_Click);
            // 
            // btnAgregar
            // 
            this.btnAgregar.Location = new System.Drawing.Point(23, 321);
            this.btnAgregar.Name = "btnAgregar";
            this.btnAgregar.Size = new System.Drawing.Size(130, 41);
            this.btnAgregar.TabIndex = 8;
            this.btnAgregar.Text = "Agregar";
            this.btnAgregar.UseVisualStyleBackColor = true;
            this.btnAgregar.Click += new System.EventHandler(this.btnAgregar_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(18, 83);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(65, 20);
            this.label1.TabIndex = 16;
            this.label1.Text = "Nombre";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(18, 124);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(125, 20);
            this.label2.TabIndex = 17;
            this.label2.Text = "Apellido Paterno";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(18, 169);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(168, 20);
            this.label3.TabIndex = 18;
            this.label3.Text = "Numero Seguro Social";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(19, 213);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(125, 20);
            this.label4.TabIndex = 20;
            this.label4.Text = "Salario Semanal";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(19, 259);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(126, 20);
            this.label5.TabIndex = 21;
            this.label5.Text = "Sueldo Por Hora";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(417, 83);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(135, 20);
            this.label6.TabIndex = 22;
            this.label6.Text = "Horas Trabajadas";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(417, 124);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(111, 20);
            this.label7.TabIndex = 23;
            this.label7.Text = "Ventas Brutas";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(417, 169);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(118, 20);
            this.label8.TabIndex = 24;
            this.label8.Text = "Tarifa Comision";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(417, 213);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(99, 20);
            this.label9.TabIndex = 25;
            this.label9.Text = "Salario Base";
            // 
            // txtNombre
            // 
            this.txtNombre.Location = new System.Drawing.Point(211, 77);
            this.txtNombre.Name = "txtNombre";
            this.txtNombre.Size = new System.Drawing.Size(163, 26);
            this.txtNombre.TabIndex = 26;
            // 
            // txtapellidoPaterno
            // 
            this.txtapellidoPaterno.Location = new System.Drawing.Point(211, 118);
            this.txtapellidoPaterno.Name = "txtapellidoPaterno";
            this.txtapellidoPaterno.Size = new System.Drawing.Size(163, 26);
            this.txtapellidoPaterno.TabIndex = 27;
            // 
            // txtnumeroSeguroSocial
            // 
            this.txtnumeroSeguroSocial.Location = new System.Drawing.Point(211, 163);
            this.txtnumeroSeguroSocial.Name = "txtnumeroSeguroSocial";
            this.txtnumeroSeguroSocial.Size = new System.Drawing.Size(163, 26);
            this.txtnumeroSeguroSocial.TabIndex = 28;
            // 
            // txtsalarioSemanal
            // 
            this.txtsalarioSemanal.Location = new System.Drawing.Point(211, 210);
            this.txtsalarioSemanal.Name = "txtsalarioSemanal";
            this.txtsalarioSemanal.Size = new System.Drawing.Size(163, 26);
            this.txtsalarioSemanal.TabIndex = 29;
            // 
            // txtsueldoPorHora
            // 
            this.txtsueldoPorHora.Location = new System.Drawing.Point(211, 253);
            this.txtsueldoPorHora.Name = "txtsueldoPorHora";
            this.txtsueldoPorHora.Size = new System.Drawing.Size(163, 26);
            this.txtsueldoPorHora.TabIndex = 30;
            // 
            // txttarifaComision
            // 
            this.txttarifaComision.Location = new System.Drawing.Point(569, 166);
            this.txttarifaComision.Name = "txttarifaComision";
            this.txttarifaComision.Size = new System.Drawing.Size(163, 26);
            this.txttarifaComision.TabIndex = 31;
            // 
            // txthorasTrabajadas
            // 
            this.txthorasTrabajadas.Location = new System.Drawing.Point(569, 80);
            this.txthorasTrabajadas.Name = "txthorasTrabajadas";
            this.txthorasTrabajadas.Size = new System.Drawing.Size(163, 26);
            this.txthorasTrabajadas.TabIndex = 32;
            // 
            // txtventasBrutas
            // 
            this.txtventasBrutas.Location = new System.Drawing.Point(569, 121);
            this.txtventasBrutas.Name = "txtventasBrutas";
            this.txtventasBrutas.Size = new System.Drawing.Size(163, 26);
            this.txtventasBrutas.TabIndex = 33;
            // 
            // txtsalarioBase
            // 
            this.txtsalarioBase.Location = new System.Drawing.Point(569, 210);
            this.txtsalarioBase.Name = "txtsalarioBase";
            this.txtsalarioBase.Size = new System.Drawing.Size(163, 26);
            this.txtsalarioBase.TabIndex = 34;
            // 
            // listView1
            // 
            this.listView1.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader0,
            this.columnHeader1,
            this.columnHeader2,
            this.columnHeader3,
            this.columnHeader4,
            this.columnHeader5,
            this.columnHeader6,
            this.columnHeader7,
            this.columnHeader8,
            this.columnHeader9});
            this.listView1.HideSelection = false;
            this.listView1.Location = new System.Drawing.Point(23, 377);
            this.listView1.Name = "listView1";
            this.listView1.Size = new System.Drawing.Size(937, 217);
            this.listView1.TabIndex = 11;
            this.listView1.UseCompatibleStateImageBehavior = false;
            this.listView1.View = System.Windows.Forms.View.Details;
            this.listView1.SelectedIndexChanged += new System.EventHandler(this.listView1_SelectedIndexChanged);
            // 
            // columnHeader0
            // 
            this.columnHeader0.Text = "Nombre";
            this.columnHeader0.Width = 91;
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "Apellido Paterno";
            this.columnHeader1.Width = 130;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "Seguro Social";
            this.columnHeader2.Width = 120;
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "Salario Semanal";
            this.columnHeader3.Width = 129;
            // 
            // columnHeader4
            // 
            this.columnHeader4.Text = "Sueldo Por Hora";
            this.columnHeader4.Width = 132;
            // 
            // columnHeader5
            // 
            this.columnHeader5.Text = "Horas Trabajadas";
            this.columnHeader5.Width = 145;
            // 
            // columnHeader6
            // 
            this.columnHeader6.Text = "Ventas Brutas";
            this.columnHeader6.Width = 123;
            // 
            // columnHeader7
            // 
            this.columnHeader7.Text = "Tarifa Comision";
            this.columnHeader7.Width = 123;
            // 
            // columnHeader8
            // 
            this.columnHeader8.Text = "Salario Base";
            this.columnHeader8.Width = 113;
            // 
            // columnHeader9
            // 
            this.columnHeader9.Text = "Pago Semanal";
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(984, 615);
            this.Controls.Add(this.txtsalarioBase);
            this.Controls.Add(this.txtventasBrutas);
            this.Controls.Add(this.txthorasTrabajadas);
            this.Controls.Add(this.txttarifaComision);
            this.Controls.Add(this.txtsueldoPorHora);
            this.Controls.Add(this.txtsalarioSemanal);
            this.Controls.Add(this.txtnumeroSeguroSocial);
            this.Controls.Add(this.txtapellidoPaterno);
            this.Controls.Add(this.txtNombre);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnLimpiar);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.btnGenerarReporte);
            this.Controls.Add(this.listView1);
            this.Controls.Add(this.btnEditar);
            this.Controls.Add(this.btnEliminar);
            this.Controls.Add(this.btnAgregar);
            this.Name = "Form2";
            this.Text = "Gestión de pagos a Empleados";
            this.Load += new System.EventHandler(this.Form2_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnLimpiar;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Button btnGenerarReporte;
        private System.Windows.Forms.Button btnEditar;
        private System.Windows.Forms.Button btnEliminar;
        private System.Windows.Forms.Button btnAgregar;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txtNombre;
        private System.Windows.Forms.TextBox txtapellidoPaterno;
        private System.Windows.Forms.TextBox txtnumeroSeguroSocial;
        private System.Windows.Forms.TextBox txtsalarioSemanal;
        private System.Windows.Forms.TextBox txtsueldoPorHora;
        private System.Windows.Forms.TextBox txttarifaComision;
        private System.Windows.Forms.TextBox txthorasTrabajadas;
        private System.Windows.Forms.TextBox txtventasBrutas;
        private System.Windows.Forms.TextBox txtsalarioBase;
        private System.Windows.Forms.ListView listView1;
        private System.Windows.Forms.ColumnHeader columnHeader0;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private System.Windows.Forms.ColumnHeader columnHeader4;
        private System.Windows.Forms.ColumnHeader columnHeader5;
        private System.Windows.Forms.ColumnHeader columnHeader6;
        private System.Windows.Forms.ColumnHeader columnHeader7;
        private System.Windows.Forms.ColumnHeader columnHeader8;
        private System.Windows.Forms.ColumnHeader columnHeader9;
    }
}